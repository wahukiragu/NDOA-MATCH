exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: 'Method not allowed' };
  }

  let data;
  try {
    data = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: 'Invalid JSON' };
  }

  const {
    name, email, city, faith_track, payment_ref,
    q1_social, q2_conflict, q3_values, q4_love_language,
    q5_money, q6_partner_sunday, q7_culture, q8_attraction,
    q9_dealbreaker, q10_five_years, q11_self_awareness,
    q12_history, q13_stress_needs, q14_family,
    q15_faith_marriage, q15_open_text,
  } = data;

  if (!email || !name) {
    return { statusCode: 400, headers, body: 'Missing required fields' };
  }

  const faithLabel = {
    A: 'Deep Faith (faith is everything)',
    B: 'Faith-Informed (faith matters to me)',
    C: 'Spiritual (spiritual but not religious)',
    D: 'Secular (not religious)',
  }[faith_track] || faith_track;

  const prompt = `You are a warm, insightful relationship counsellor writing a personalised marriage partner report for a Kenyan user. Write in a warm, affirming, and culturally aware tone.

USER PROFILE:
- Name: ${name}
- City: ${city}
- Faith track: ${faithLabel}
- Payment reference: ${payment_ref}

THEIR QUIZ ANSWERS:
1. Social style: ${q1_social}
2. Conflict approach: ${q2_conflict}
3. Core values: ${q3_values}
4. Love language: ${q4_love_language}
5. Money mindset: ${q5_money}
6. Partner's Sunday / weekend ideal: ${q6_partner_sunday}
7. Cultural background importance: ${q7_culture}
8. Attraction style: ${q8_attraction}
9. Dealbreaker: ${q9_dealbreaker}
10. Five-year vision: ${q10_five_years}
11. Self-awareness: ${q11_self_awareness}
12. Relationship history: ${q12_history}
13. Stress and emotional needs: ${q13_stress_needs}
14. Family and in-laws: ${q14_family}
15. Faith and marriage view: ${q15_faith_marriage}
    Open reflection: ${q15_open_text || 'None provided'}

Write a personalised marriage partner report in HTML format with exactly these four sections:

<h2>Who you are</h2>
[3-4 sentences affirming their personality, values, and what makes them a great partner candidate]

<h2>What you need in a partner</h2>
[4-5 sentences describing the specific type of person who would complement them well, based on their answers]

<h2>Watch out for</h2>
[3-4 sentences of honest, kind advice about patterns or blind spots they should be aware of in their relationship journey]

<h2>Your NdoaMatch score</h2>
[Give them a readiness score out of 10 with one line explanation. Then 2-3 sentences of encouragement tailored to their faith track.]

Use <p> tags for paragraphs. Use ${name}'s name naturally throughout. Keep the entire report to about 400 words. Do not include any preamble — start directly with the first <h2> tag.`;

  let reportHtml;
  try {
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!claudeRes.ok) {
      const err = await claudeRes.text();
      console.error('Claude API error:', err);
      return { statusCode: 500, headers, body: 'Report generation failed' };
    }

    const claudeData = await claudeRes.json();
    reportHtml = claudeData.content[0].text;
  } catch (err) {
    console.error('Claude fetch error:', err);
    return { statusCode: 500, headers, body: 'Report generation failed' };
  }

  const emailHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body { font-family: Georgia, serif; background: #fdf8f3; margin: 0; padding: 0; }
  .wrapper { max-width: 600px; margin: 0 auto; padding: 32px 16px; }
  .card { background: #ffffff; border-radius: 12px; padding: 40px 36px; border: 1px solid #e8e0d8; }
  .logo { font-size: 22px; font-weight: bold; color: #7c3d1e; letter-spacing: 1px; margin-bottom: 8px; }
  .tagline { color: #a07050; font-size: 13px; margin-bottom: 32px; }
  .greeting { font-size: 18px; color: #2d1a0e; margin-bottom: 24px; }
  h2 { color: #7c3d1e; font-size: 16px; margin: 28px 0 8px; text-transform: uppercase; letter-spacing: 0.5px; }
  p { color: #3d2510; line-height: 1.7; font-size: 15px; margin: 0 0 12px; }
  .divider { border: none; border-top: 1px solid #e8e0d8; margin: 32px 0; }
  .footer { text-align: center; color: #a07050; font-size: 12px; margin-top: 32px; }
  .ref { background: #fdf0e8; border-radius: 6px; padding: 8px 14px; font-size: 12px; color: #a07050; display: inline-block; margin-top: 8px; }
</style>
</head>
<body>
<div class="wrapper">
  <div class="card">
    <div class="logo">NdoaMatch</div>
    <div class="tagline">Know who you're called to marry</div>
    <p class="greeting">Dear ${name},</p>
    <p>Here is your personalised marriage partner report. We hope it gives you clarity, confidence, and direction as you seek your life partner.</p>
    <hr class="divider">
    ${reportHtml}
    <hr class="divider">
    <div class="footer">
      <p>This report was generated for ${email}</p>
      <span class="ref">Ref: ${payment_ref}</span>
      <p style="margin-top:16px">NdoaMatch &mdash; &copy; 2026 IPWORTH LTD</p>
    </div>
  </div>
</div>
</body>
</html>`;

  try {
    const emailRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: 'NdoaMatch <reports@yourdomain.com>',
        to: email,
        subject: `${name}, your NdoaMatch report is ready`,
        html: emailHtml,
      }),
    });

    if (!emailRes.ok) {
      const err = await emailRes.text();
      console.error('Resend error:', err);
      return { statusCode: 500, headers, body: 'Email delivery failed' };
    }
  } catch (err) {
    console.error('Email fetch error:', err);
    return { statusCode: 500, headers, body: 'Email delivery failed' };
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({ success: true, message: 'Report sent successfully' }),
  };
};
