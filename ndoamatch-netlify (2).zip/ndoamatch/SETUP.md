# NdoaMatch — Netlify Setup Guide
## No Zapier needed. Free. Permanent.

---

## What changed
Your quiz now sends data directly to a Netlify serverless function instead of Zapier.
The function calls Claude AI to generate the report, then emails it via Resend.

---

## Accounts you need (all free tiers sufficient)

| Service | Purpose | Free tier |
|---|---|---|
| Netlify | Host your site + run the function | Unlimited sites, 125k function calls/month |
| Anthropic | Claude AI for report generation | Pay per use (~$0.01 per report) |
| Resend | Send the email report | 3,000 emails/month free |

---

## Step 1 — Sign up for Resend (email sending)

1. Go to https://resend.com and create a free account
2. Add your domain (e.g. ndoamatch.com) under **Domains** and verify it
   - If you don't have a domain yet, Resend gives you a test address like `onboarding@resend.dev` — use that while testing
3. Go to **API Keys** → create a new key → copy it (you'll need it in Step 3)
4. Open `netlify/functions/generate-report.js` and update this line:
   ```
   from: 'NdoaMatch <reports@yourdomain.com>',
   ```
   Replace `reports@yourdomain.com` with your verified Resend sender address

---

## Step 2 — Deploy to Netlify

1. Go to https://netlify.com → **Add new site** → **Import an existing project**
2. Connect your GitHub account and select your NdoaMatch repository
3. Build settings will be detected automatically from `netlify.toml`
4. Click **Deploy site**

Your site will be live at something like `https://ndoamatch.netlify.app`

---

## Step 3 — Add your secret keys in Netlify

This is the most important step. Go to:
**Netlify dashboard → Your site → Site configuration → Environment variables**

Add these two variables:

| Key | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your key from https://console.anthropic.com (starts with `sk-ant-...`) |
| `RESEND_API_KEY` | Your key from https://resend.com (starts with `re_...`) |

Click **Save** after adding each one.

Then go to **Deploys → Trigger deploy → Deploy site** to redeploy with the new keys active.

---

## Step 4 — Test it

1. Visit your Netlify URL
2. Complete the quiz
3. Use Paystack's test card: `4084 0840 8408 4081`, expiry `01/99`, CVV `408`
4. Check the email inbox you entered — your report should arrive within 60 seconds

---

## Step 5 — Go live with Paystack

In `index.html` line 356, your Paystack key is already set to live mode:
```
const PAYSTACK_PUBLIC_KEY = 'pk_live_75ef9f6a...';
```
This is correct — no change needed.

---

## Troubleshooting

**No email received?**
- Go to Netlify → **Functions** tab → click `generate-report` → view logs
- The logs will show exactly what went wrong (API key error, email error, etc.)

**Function timeout?**
- Netlify free functions have a 10-second timeout
- Claude usually responds in 5–8 seconds — should be fine
- If timeouts persist, upgrade to Netlify Pro ($19/mo) for 26-second timeout

**Resend "domain not verified" error?**
- Use `onboarding@resend.dev` as the sender while your domain verifies
- Domain DNS changes can take up to 48 hours

---

## File structure

```
ndoamatch/
├── index.html                          ← Your quiz (updated to call Netlify function)
├── netlify.toml                        ← Netlify config (updated)
├── netlify/
│   └── functions/
│       └── generate-report.js          ← NEW: the serverless function
└── SETUP.md                            ← This file
```

---

## Cost estimate

At 100 users/month paying KES 250:
- Revenue: KES 25,000
- Claude API cost: ~$1 (100 reports × ~$0.01 each)
- Netlify: Free
- Resend: Free (under 3,000 emails)
- **Net: essentially KES 25,000 minus Paystack's ~1.5% fee**
